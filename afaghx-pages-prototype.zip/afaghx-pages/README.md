# AFAGHX GitHub Pages Prototype

Static Experience-layer prototype for the AFAGHX ecosystem.

- Source: `experience/prototype/`
- Workflow: `.github/workflows/afaghx-pages.yml`
- Intended URL: `https://afaghx-afaghx.github.io/platform/`

This prototype is visual/demo-only. It does not bypass AFX-CORE, domain persistence, or production authorization boundaries.
